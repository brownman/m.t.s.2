#!/bin/bash -xe

echo "hello world!"
notify-send hi
echo hi | flite
