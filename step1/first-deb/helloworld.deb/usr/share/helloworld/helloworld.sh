#!/bin/bash

echo "hello world!"
sleep 10
